create
    definer = root@localhost function partnerCim(raId int) returns varchar(200)
BEGIN
	DECLARE cim VARCHAR(200);
	select concat(t.isz, ' ', t1.telepules,' ', t.cim) into cim from partner t, telepules t1
	where t1.id = t.telepules and t.id = raId;    
	RETURN cim;
END;

