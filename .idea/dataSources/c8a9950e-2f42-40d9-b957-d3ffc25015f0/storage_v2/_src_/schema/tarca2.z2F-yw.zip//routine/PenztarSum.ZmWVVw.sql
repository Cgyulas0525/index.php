create
    definer = root@localhost function PenztarSum(raId int) returns int
BEGIN
	DECLARE v_sum INT(10);
	DECLARE v_5 INT(5);
	DECLARE v_10 INT(5);
	DECLARE v_20 INT(5);
	DECLARE v_50 INT(5);
	DECLARE v_100 INT(5);
	DECLARE v_200 INT(5);
	DECLARE v_500 INT(5);
	DECLARE v_1000 INT(5);
	DECLARE v_2000 INT(5);
	DECLARE v_5000 INT(5);
	DECLARE v_10000 INT(5);
	DECLARE v_20000 INT(5);
    DECLARE v_kartya INT(5);
    DECLARE v_napkozben INT(5);
	
    SELECT t.A5, t.A10, t.A20, t.A50, t.A100, t.A200, t.A500, t.A1000, t.A2000, t.A5000, t.A10000, t.A20000, t.kartya, t.napkozben
      INTO v_5, v_10, v_20, v_50, v_100, v_200, v_500, v_1000, v_2000, v_5000, v_10000, v_20000, v_kartya, v_napkozben
      FROM zaras t WHERE t.id = raId;
	SET v_sum = (v_5 * 5) + (v_10 * 10)  + (v_20 * 20) + (v_50 * 50) + (v_100 * 100) + (v_200 * 200) + (v_500 * 500) + (v_1000 * 1000) + (v_2000 * 2000) + (v_5000 * 5000) + (v_10000 * 10000) + (v_20000 * 20000) + v_kartya + v_napkozben;
    SET v_sum = v_sum - 20000;
RETURN(v_sum);
END;

